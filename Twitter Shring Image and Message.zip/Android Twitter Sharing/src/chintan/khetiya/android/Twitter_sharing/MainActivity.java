package chintan.khetiya.android.Twitter_sharing;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import chintan.khetiya.android.Twitter_code.Twitt_Sharing;

//In case if you get any error then check out the jar file version. it should be latest one.

public class MainActivity extends Activity {

	// Replace your KEY here and Run ,
	public final String consumer_key = "8QrInt4Slc7KiyRc3L4ww";
	public final String secret_key = "dSXcjXQbDTxhNt8yOyhKpcPOZbrRDulVWw9MafoMMQ";
	File casted_image;

	String string_img_url = null, string_msg = null;
	Button btn;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		try {
			setContentView(R.layout.main);

			if (Build.VERSION.SDK_INT >= 9) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}
		
			btn = (Button) findViewById(R.id.btn);
			btn.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					// new Thread(new Runnable() {
					//
					// @Override
					// public void run() {
					// // TODO Auto-generated method stub
					// onClickTwitt();
					// }
					// });
					onClickTwitt();
				}
			});
		} catch (Exception e) {
			// TODO: handle exception
			showToast("View problem");
		}
	}

	public void Call_My_Blog(View v) {
		Intent intent = new Intent(MainActivity.this, My_Blog.class);
		startActivity(intent);

	}

	// Here you can pass the string message & image path which you want to share
	// in Twitter.
	public void onClickTwitt() {

		if (isNetworkAvailable()) {
			Twitt_Sharing twitt = new Twitt_Sharing(MainActivity.this,consumer_key, secret_key);
			// here we have web url image so we have to make it as file to
			// upload

			//String_to_File(string_img_url);

			try {

				string_msg = "http://intetithub.com";
				URL url = new URL("http://blog.heartland.org/wp-content/uploads/2013/07/Google.jpg");
				URLConnection connection = url.openConnection();
				connection.connect();

				/*runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						try {
							
							//string_img_url = "http://s30.postimg.org/gynymvuz1/attachment.png";
							string_msg = "http://intetithub.com";
							URL url = new URL("http://s30.postimg.org/gynymvuz1/attachment.png");
							URLConnection connection = url.openConnection();
							connection.connect();
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});*/
				

				// download the file
				InputStream input = new BufferedInputStream(url.openStream());
				OutputStream output = new FileOutputStream(Environment.getExternalStorageDirectory() +"/attachment.png");

				byte data[] = new byte[2048];
				long total = 0;
				int count;
				while ((count = input.read(data)) != -1) {
					total += count;
					output.write(data, 0, count);
				}

				output.flush();
				output.close();
				input.close();
			} catch (Exception e) {
				e.printStackTrace();
			}


			File rootSdDirectory = Environment.getExternalStorageDirectory();

			casted_image = new File(rootSdDirectory, "attachment.png");

			/*File rootSdDirectory = Environment.getExternalStorageDirectory();

			casted_image =rootSdDirectory+"/attachment.png";*/

			// Now share both message & image to sharing activity
			twitt.shareToTwitter(string_msg, casted_image);

		} else {
			showToast("No Network Connection Available !!!");
		}
	}

	// when user will click on twitte then first that will check that is
	// internet exist or not
	public boolean isNetworkAvailable() {
		ConnectivityManager connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity == null) {
			return false;
		} else {
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null) {
				for (int i = 0; i < info.length; i++) {
					if (info[i].getState() == NetworkInfo.State.CONNECTED) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private void showToast(String msg) {
		Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();

	}

	// this function will make your image to file
	public File String_to_File(String img_url) {

		try {
			// File rootSdDirectory = Environment.getExternalStorageDirectory();
			//
			// casted_image = new File(rootSdDirectory, "attachment.png");
			// if (casted_image.exists()) {
			// casted_image.delete();
			// }
			// casted_image.createNewFile();
			//
			// FileOutputStream fos = new FileOutputStream(casted_image);
			//
			// URL url = new URL(img_url);
			// HttpURLConnection connection = (HttpURLConnection) url
			// .openConnection();
			// connection.setRequestMethod("GET");
			// connection.setDoOutput(true);
			// connection.connect();
			// InputStream in = connection.getInputStream();
			//
			// byte[] buffer = new byte[1024];
			// int size = 0;
			// while ((size = in.read(buffer)) > 0) {
			// fos.write(buffer, 0, size);
			// }
			// fos.close();
			return casted_image;

		} catch (Exception e) {

			System.out.print(e);
			// e.printStackTrace();

		}
		return casted_image;
	}

}
